<?php 

	$config['sid'] = "yourtwiliosid";
	$config['token'] = "yourtwiliotoken";
	$config['phone'] = "+yourtwiliophone";
?>
